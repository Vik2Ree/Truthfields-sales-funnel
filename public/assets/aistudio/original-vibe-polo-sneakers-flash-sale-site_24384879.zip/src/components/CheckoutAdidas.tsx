import React, { useState, useRef } from 'react';
import {
  Lock,
  ArrowLeft,
  Truck,
  Award,
  ShieldCheck,
  Check,
  Phone,
  MapPin,
  Clock,
  Sparkles,
  ChevronDown,
  AlertCircle,
  Plus,
  MessageSquare,
} from 'lucide-react';
import { Colorway, BundleOption, AddonItem, OrderData } from '../types';
import {
  ADDONS,
  NIGERIAN_STATES,
  SNEAKER_PRODUCT,
  COLORWAYS,
  SIZES,
  BUNDLE_OPTIONS,
} from '../data/productData';

interface CheckoutAdidasProps {
  selectedColorway: Colorway;
  onSelectColorway: (colorway: Colorway) => void;
  selectedSize: number;
  onSelectSize: (size: number) => void;
  selectedBundle: BundleOption;
  onSelectBundle: (bundle: BundleOption) => void;
  onOpenSizeGuide: () => void;
  onBack: () => void;
  onOrderComplete: (order: OrderData) => void;
}

export const CheckoutAdidas: React.FC<CheckoutAdidasProps> = ({
  selectedColorway,
  onSelectColorway,
  selectedSize,
  onSelectSize,
  selectedBundle,
  onSelectBundle,
  onOpenSizeGuide,
  onBack,
  onOrderComplete,
}) => {
  // Stepped progression: 1 = Selection, 2 = Delivery, 3 = Speed, 4 = Payment (POD)
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [hasSeparateWhatsapp, setHasSeparateWhatsapp] = useState(false);
  const [whatsapp, setWhatsapp] = useState('');
  const [streetAddress, setStreetAddress] = useState('');
  const [state, setState] = useState('Lagos');
  const [landmark, setLandmark] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');

  const fullName = `${firstName} ${lastName}`.trim();

  // Shipping & Payment Options
  const [deliveryMethod, setDeliveryMethod] = useState<'standard_free' | 'vip_express'>(
    'standard_free'
  );
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'instant_transfer'>('cod');

  // Addons / Order Bumps
  const [selectedAddonIds, setSelectedAddonIds] = useState<string[]>([]);

  // Mobile Order Summary Drawer
  const [showMobileSummary, setShowMobileSummary] = useState(false);

  // Submitting State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const toggleAddon = (id: string) => {
    setSelectedAddonIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const deliveryFee = deliveryMethod === 'vip_express' ? 3000 : 0;
  const addonsTotal = selectedAddonIds.reduce((sum, id) => {
    const found = ADDONS.find((a) => a.id === id);
    return sum + (found ? found.price : 0);
  }, 0);

  const grandTotal = selectedBundle.totalPrice + deliveryFee + addonsTotal;

  // Validation for Step 2 (Delivery Address)
  const validateStep2 = () => {
    const newErrors: { [key: string]: string } = {};
    if (!firstName.trim()) newErrors.firstName = 'Please enter your first name';
    if (!lastName.trim()) newErrors.lastName = 'Please enter your last name';
    if (!phone.trim()) {
      newErrors.phone = 'Please enter a valid phone number for courier call';
    } else if (phone.replace(/[^0-9]/g, '').length < 10) {
      newErrors.phone = 'Phone number must be at least 10 digits';
    }
    if (hasSeparateWhatsapp) {
      if (!whatsapp.trim()) {
        newErrors.whatsapp = 'Please enter your WhatsApp phone number';
      } else if (whatsapp.replace(/[^0-9]/g, '').length < 10) {
        newErrors.whatsapp = 'WhatsApp number must be at least 10 digits';
      }
    }
    if (!streetAddress.trim()) {
      newErrors.streetAddress = 'Please enter your street address and house / flat no.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Step element references for targeted, smooth, calm scrolling
  const step1Ref = useRef<HTMLDivElement>(null);
  const step2Ref = useRef<HTMLDivElement>(null);
  const step3Ref = useRef<HTMLDivElement>(null);
  const step4Ref = useRef<HTMLDivElement>(null);

  const scrollToStep = (stepNumber: 1 | 2 | 3 | 4) => {
    // Wait for the next tick so React has applied DOM changes and container heights
    requestAnimationFrame(() => {
      setTimeout(() => {
        const refMap: Record<number, HTMLDivElement | null> = {
          1: step1Ref.current,
          2: step2Ref.current,
          3: step3Ref.current,
          4: step4Ref.current,
        };
        const targetEl = refMap[stepNumber];
        if (!targetEl) return;

        // Sticky header is ~55-65px; 80px offset ensures step header sits comfortably in view
        const headerOffset = window.innerWidth < 640 ? 76 : 84;
        const startY = window.pageYOffset || document.documentElement.scrollTop;
        const rect = targetEl.getBoundingClientRect();
        const targetY = Math.max(0, rect.top + startY - headerOffset);
        const distance = targetY - startY;

        // If already practically at the target, no scroll needed
        if (Math.abs(distance) < 8) return;

        // Slower, graceful scroll animation duration (750ms)
        const duration = 750;
        let startTime: number | null = null;
        let isCancelled = false;

        const onUserCancel = () => {
          isCancelled = true;
          window.removeEventListener('wheel', onUserCancel);
          window.removeEventListener('touchmove', onUserCancel);
        };

        window.addEventListener('wheel', onUserCancel, { passive: true });
        window.addEventListener('touchmove', onUserCancel, { passive: true });

        // Smooth cubic ease-in-out curve: slow initiation, seamless glide, gentle landing
        const easeInOutCubic = (t: number) => {
          return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        };

        const animateScroll = (currentTime: number) => {
          if (isCancelled) return;
          if (startTime === null) startTime = currentTime;
          const timeElapsed = currentTime - startTime;
          const progress = Math.min(timeElapsed / duration, 1);
          const ease = easeInOutCubic(progress);

          window.scrollTo(0, startY + distance * ease);

          if (timeElapsed < duration) {
            requestAnimationFrame(animateScroll);
          } else {
            window.removeEventListener('wheel', onUserCancel);
            window.removeEventListener('touchmove', onUserCancel);
          }
        };

        requestAnimationFrame(animateScroll);
      }, 70);
    });
  };

  const handleProceedToStep2 = () => {
    setCurrentStep(2);
    scrollToStep(2);
  };

  const handleProceedToStep3 = () => {
    if (validateStep2()) {
      setCurrentStep(3);
      scrollToStep(3);
    } else {
      scrollToStep(2);
    }
  };

  const handleProceedToStep4 = () => {
    setCurrentStep(4);
    scrollToStep(4);
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep2()) {
      setCurrentStep(2);
      scrollToStep(2);
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      // Generate unique order ID
      const randomSuffix = Math.floor(100000 + Math.random() * 900000);
      const orderId = `POLO-NG-${randomSuffix}`;

      // Estimated arrival
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + (state === 'Lagos' || state.includes('Abuja') ? 1 : 2));
      const formattedDate = tomorrow.toLocaleDateString('en-GB', {
        weekday: 'long',
        month: 'short',
        day: 'numeric',
      });

      const chosenAddons: AddonItem[] = ADDONS.filter((a) => selectedAddonIds.includes(a.id));

      const newOrder: OrderData = {
        orderId,
        createdAt: new Date().toISOString(),
        customer: {
          fullName: fullName || `${firstName} ${lastName}`.trim() || 'Customer',
          firstName,
          lastName,
          phone,
          whatsapp: hasSeparateWhatsapp && whatsapp.trim() ? whatsapp.trim() : phone.trim(),
          hasSeparateWhatsapp,
          streetAddress,
          state,
          city: state,
          landmark,
          deliveryNotes,
        },
        items: [
          {
            colorway: selectedColorway,
            size: selectedSize,
            quantity: selectedBundle.pairs,
          },
        ],
        bundleTier: selectedBundle.pairs,
        deliveryMethod,
        deliveryFee,
        selectedAddons: chosenAddons,
        paymentMethod,
        subtotal: selectedBundle.totalPrice,
        discount: selectedBundle.savingsTotal,
        grandTotal,
        status: 'confirmed',
        estimatedDeliveryDate: formattedDate,
      };

      setIsSubmitting(false);
      onOrderComplete(newOrder);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F3] text-[#141414] pb-24">
      {/* Light-themed Minimalist Header */}
      <header className="bg-[#FAF9F5]/95 backdrop-blur-md text-[#141414] border-b border-[#E7E4DC] px-4 sm:px-6 py-3.5 sm:py-4 sticky top-0 z-30 shadow-xs">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 text-xs uppercase tracking-wider font-semibold text-[#5C574F] hover:text-[#141414] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back to Product</span>
            <span className="sm:hidden">Back</span>
          </button>

          <div className="flex flex-col items-center">
            <span className="font-crest text-[10px] tracking-[0.3em] uppercase text-[#735D43] font-semibold">
              TRUTHFIELD INT'L LTD
            </span>
            <span className="font-editorial text-sm sm:text-base font-bold tracking-widest uppercase text-[#141414]">
              CHECKOUT
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-[#2D6A4F] font-semibold">
            <Lock className="w-3.5 h-3.5 text-[#52B788]" />
            <span className="hidden sm:inline">256-Bit SSL Encrypted</span>
            <span className="sm:hidden">Secure</span>
          </div>
        </div>
      </header>

      {/* Stepped Progress Bar */}
      <div className="bg-white border-b border-[#E5E3DC] px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between text-xs font-semibold uppercase tracking-wider">
          <button
            type="button"
            onClick={() => {
              setCurrentStep(1);
              scrollToStep(1);
            }}
            className={`flex items-center gap-2 cursor-pointer ${
              currentStep === 1 ? 'text-black border-b-2 border-black pb-1' : 'text-[#8C877E]'
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono ${
                currentStep >= 1 ? 'bg-black text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              1
            </span>
            <span>Selection</span>
          </button>

          <span className="text-gray-300">———</span>

          <button
            type="button"
            onClick={() => {
              setCurrentStep(2);
              scrollToStep(2);
            }}
            className={`flex items-center gap-2 cursor-pointer ${
              currentStep === 2 ? 'text-black border-b-2 border-black pb-1' : 'text-[#8C877E]'
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono ${
                currentStep >= 2 ? 'bg-black text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              2
            </span>
            <span>Delivery</span>
          </button>

          <span className="text-gray-300">———</span>

          <button
            type="button"
            onClick={() => {
              if (validateStep2()) {
                setCurrentStep(3);
                scrollToStep(3);
              } else {
                scrollToStep(2);
              }
            }}
            className={`flex items-center gap-2 cursor-pointer ${
              currentStep === 3 ? 'text-black border-b-2 border-black pb-1' : 'text-[#8C877E]'
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono ${
                currentStep >= 3 ? 'bg-black text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              3
            </span>
            <span>Speed</span>
          </button>

          <span className="text-gray-300">———</span>

          <button
            type="button"
            onClick={() => {
              if (validateStep2()) {
                setCurrentStep(4);
                scrollToStep(4);
              } else {
                scrollToStep(2);
              }
            }}
            className={`flex items-center gap-2 cursor-pointer ${
              currentStep === 4 ? 'text-black border-b-2 border-black pb-1' : 'text-[#8C877E]'
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono ${
                currentStep >= 4 ? 'bg-black text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              4
            </span>
            <span>Payment (POD)</span>
          </button>
        </div>
      </div>

      {/* Main Checkout Grid */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-6">
        {/* Mobile Accordion Toggle for Order Summary */}
        <div className="lg:hidden mb-4 bg-white border border-[#E5E3DC] p-3 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setShowMobileSummary(!showMobileSummary)}
            className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-black cursor-pointer"
          >
            <span>{showMobileSummary ? 'Hide Order Summary' : 'View Order Summary'}</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform ${showMobileSummary ? 'rotate-180' : ''}`}
            />
          </button>
          <div className="text-sm font-bold font-mono text-black tabular-nums">
            ₦{grandTotal.toLocaleString()}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* ================= LEFT 7 COLS: FORM STEPS ================= */}
          <div className="lg:col-span-7 space-y-6">
            {/* Trust Reassurance Strip */}
            <div className="bg-[#EBF7EE] border border-[#52B788] p-3.5 flex items-center gap-3">
              <ShieldCheck className="w-6 h-6 text-[#144729] shrink-0" />
              <div className="text-xs text-[#144729]">
                <strong className="font-bold uppercase tracking-wider block">
                  Payment on Delivery Active
                </strong>
                <span>You only pay when the rider delivers and you inspect the shoes.</span>
              </div>
            </div>

            {/* ================= STEP 1: SNEAKER & BUNDLE SELECTION ================= */}
            <div
              ref={step1Ref}
              className={`bg-white border transition-all ${
                currentStep === 1
                  ? 'border-black shadow-sm p-5 sm:p-6'
                  : 'border-[#E0DBD0] p-4 opacity-90'
              }`}
            >
              <div className="flex items-center justify-between border-b border-[#E7E4DC] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-black text-white text-xs font-mono font-bold flex items-center justify-center">
                    1
                  </span>
                  <h2 className="font-editorial text-lg font-bold uppercase tracking-wide">
                    Purchasing Options & Selection
                  </h2>
                </div>
                {currentStep !== 1 && (
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentStep(1);
                      scrollToStep(1);
                    }}
                    className="text-xs font-semibold text-[#842A46] uppercase hover:underline cursor-pointer"
                  >
                    Edit
                  </button>
                )}
              </div>

              {currentStep === 1 ? (
                <div className="space-y-6">
                  {/* Colorway Selection */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="uppercase font-semibold tracking-wider text-[#141414]">
                        Select Colorway:
                      </span>
                      <span className="font-medium text-[#735D43]">{selectedColorway.name}</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-2.5">
                      {COLORWAYS.map((c) => {
                        const isSelected = selectedColorway.id === c.id;
                        return (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => onSelectColorway(c)}
                            className={`p-2 sm:p-2.5 border text-left transition-all cursor-pointer relative flex flex-col justify-between ${
                              isSelected
                                ? 'border-[#141414] bg-white ring-2 ring-[#141414] shadow-sm'
                                : 'border-[#D9D3C5] bg-[#F8F6F0] hover:border-[#8C877E] hover:bg-white'
                            }`}
                          >
                            <div className="space-y-1.5 w-full">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span
                                  className="w-3.5 h-3.5 rounded-full border border-black/25 shrink-0 shadow-xs"
                                  style={{ backgroundColor: c.swatchHex }}
                                />
                                <span className="text-[11px] font-bold text-[#141414] truncate">
                                  {c.name}
                                </span>
                              </div>

                              <div className="aspect-[4/3] w-full overflow-hidden bg-[#ECE8DF] border border-black/5 relative">
                                <img
                                  src={c.image}
                                  alt={c.name}
                                  className="w-full h-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                                {c.badge && (
                                  <span className="absolute top-1 left-1 bg-black/85 text-white text-[8px] font-bold px-1 py-0.5 uppercase tracking-wider">
                                    {c.badge}
                                  </span>
                                )}
                              </div>
                            </div>

                            <div className="mt-1.5 flex items-center justify-between text-[10px] text-[#735D43]">
                              <span className="truncate uppercase font-medium tracking-tight">
                                {c.code.split('/')[0].trim()}
                              </span>
                              {isSelected && (
                                <span className="bg-[#141414] text-white p-0.5 ml-1 shrink-0">
                                  <Check className="w-2.5 h-2.5" />
                                </span>
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Size Selection */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="uppercase font-semibold tracking-wider text-[#141414]">
                        Select Size:
                      </span>
                      <button
                        type="button"
                        onClick={onOpenSizeGuide}
                        className="text-[#842A46] font-semibold underline underline-offset-2 hover:text-[#141414] transition-colors cursor-pointer"
                      >
                        Size & Fit Guide
                      </button>
                    </div>

                    <div className="grid grid-cols-6 gap-2">
                      {SIZES.map((s) => {
                        const isSelected = selectedSize === s.eu;
                        return (
                          <button
                            key={s.eu}
                            type="button"
                            onClick={() => onSelectSize(s.eu)}
                            className={`py-2.5 sm:py-3 border text-center transition-all cursor-pointer font-mono tabular-nums ${
                              isSelected
                                ? 'bg-[#141414] text-white border-[#141414] font-bold shadow-sm'
                                : 'bg-white text-[#141414] border-[#D9D3C5] hover:border-[#141414]'
                            }`}
                          >
                            <div className="text-sm sm:text-base font-bold leading-none">{s.eu}</div>
                            <div className="text-[9px] uppercase tracking-tight text-[#8C877E] mt-0.5">
                              UK {s.uk}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Bundle Multiplier Selector */}
                  <div className="space-y-2 pt-2 border-t border-[#E7E4DC]">
                    <span className="block text-xs uppercase font-semibold tracking-wider text-[#141414]">
                      Choose Quantity / Bundle Deal:
                    </span>

                    <div className="space-y-2">
                      {BUNDLE_OPTIONS.map((b) => {
                        const isSelected = selectedBundle.pairs === b.pairs;
                        return (
                          <div
                            key={b.pairs}
                            onClick={() => onSelectBundle(b)}
                            className={`p-3 border flex items-center justify-between cursor-pointer transition-all ${
                              isSelected
                                ? 'border-[#842A46] bg-[#FCF8F9] ring-1 ring-[#842A46]'
                                : 'border-[#D9D3C5] bg-white hover:border-[#141414]'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div
                                className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                                  isSelected
                                    ? 'border-[#842A46] bg-[#842A46] text-white'
                                    : 'border-[#8C877E]'
                                }`}
                              >
                                {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                              </div>
                              <div>
                                <div className="text-xs sm:text-sm font-bold text-[#141414]">
                                  {b.label}
                                </div>
                                <div className="text-[11px] text-[#736E65]">
                                  ₦{b.pricePerPair.toLocaleString()} per pair · Save ₦{b.savingsTotal.toLocaleString()}
                                </div>
                              </div>
                            </div>

                            <div className="text-right">
                              <div className="text-sm sm:text-base font-bold text-[#141414] font-mono tabular-nums">
                                ₦{b.totalPrice.toLocaleString()}
                              </div>
                              {b.badge && (
                                <span className="inline-block bg-[#E5A83B] text-black text-[9px] font-bold px-1.5 py-0.2 uppercase tracking-wide">
                                  {b.badge}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Confidence Pillars */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3 pt-3 border-t border-[#E7E4DC]">
                    <div className="p-2.5 sm:p-3 bg-[#F3EFE6] border border-[#E8E4DA] flex items-center gap-3 text-left">
                      <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0 shadow-2xs">
                        <Truck className="w-4 h-4 text-[#141414]" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-[#141414] leading-tight">24–48h Delivery</div>
                        <div className="text-[10px] sm:text-[11px] text-[#736E65]">To your doorstep / office</div>
                      </div>
                    </div>
                    <div className="p-2.5 sm:p-3 bg-[#F3EFE6] border border-[#E8E4DA] flex items-center gap-3 text-left">
                      <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0 shadow-2xs">
                        <Award className="w-4 h-4 text-[#842A46]" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-[#141414] leading-tight">100% Authentic</div>
                        <div className="text-[10px] sm:text-[11px] text-[#736E65]">Truthfield Guarantee</div>
                      </div>
                    </div>
                  </div>

                  {/* Continue to Step 2 Button */}
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={handleProceedToStep2}
                      className="w-full py-4 px-6 bg-[#842A46] hover:bg-[#6f2239] active:scale-[0.99] text-white text-xs sm:text-sm font-bold uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                    >
                      <span>Continue to Delivery Address →</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <img
                      src={selectedColorway.image}
                      alt={selectedColorway.name}
                      className="w-12 h-12 object-cover border border-[#D9D3C5] bg-[#ECE8DF]"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-bold text-[#141414]">{selectedColorway.name}</div>
                      <div className="text-[#735D43]">
                        Size: EU {selectedSize} · {selectedBundle.label} (₦{selectedBundle.totalPrice.toLocaleString()})
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentStep(1);
                      scrollToStep(1);
                    }}
                    className="text-xs font-semibold text-[#842A46] uppercase hover:underline cursor-pointer"
                  >
                    Change Selection
                  </button>
                </div>
              )}
            </div>

            {/* ================= STEP 2: DELIVERY & CONTACT DETAILS ================= */}
            <div
              ref={step2Ref}
              className={`bg-white border transition-all ${
                currentStep === 2
                  ? 'border-black shadow-sm p-5 sm:p-6'
                  : 'border-[#E0DBD0] p-4 opacity-90'
              }`}
            >
              <div className="flex items-center justify-between border-b border-[#E7E4DC] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-black text-white text-xs font-mono font-bold flex items-center justify-center">
                    2
                  </span>
                  <h2 className="font-editorial text-lg font-bold uppercase tracking-wide">
                    Delivery Address & Contact
                  </h2>
                </div>
                {currentStep > 2 && (
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentStep(2);
                      scrollToStep(2);
                    }}
                    className="text-xs font-semibold text-[#842A46] uppercase hover:underline cursor-pointer"
                  >
                    Edit
                  </button>
                )}
              </div>

              {currentStep === 2 ? (
                <div className="space-y-4">
                  {/* First Name & Last Name */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#141414] mb-1">
                        First Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Babatunde"
                        value={firstName}
                        onChange={(e) => {
                          setFirstName(e.target.value);
                          if (errors.firstName) setErrors({ ...errors, firstName: '' });
                        }}
                        className={`w-full px-3.5 py-3 text-sm bg-[#FAF9F5] border rounded-none focus:outline-none focus:border-black transition-colors ${
                          errors.firstName ? 'border-red-500' : 'border-[#D9D3C5]'
                        }`}
                      />
                      {errors.firstName && (
                        <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> {errors.firstName}
                        </p>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#141414] mb-1">
                        Last Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Adeleke"
                        value={lastName}
                        onChange={(e) => {
                          setLastName(e.target.value);
                          if (errors.lastName) setErrors({ ...errors, lastName: '' });
                        }}
                        className={`w-full px-3.5 py-3 text-sm bg-[#FAF9F5] border rounded-none focus:outline-none focus:border-black transition-colors ${
                          errors.lastName ? 'border-red-500' : 'border-[#D9D3C5]'
                        }`}
                      />
                      {errors.lastName && (
                        <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> {errors.lastName}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Phone Number (as it currently is) */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#141414] mb-1 flex items-center justify-between">
                      <span>
                        Phone Number <span className="text-red-500">*</span>
                      </span>
                      <span className="text-[10px] text-[#735D43] font-normal">
                        For dispatch call
                      </span>
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-[#8C877E] absolute left-3 top-3.5" />
                      <input
                        type="tel"
                        placeholder="0801 234 5678"
                        value={phone}
                        onChange={(e) => {
                          setPhone(e.target.value);
                          if (errors.phone) setErrors({ ...errors, phone: '' });
                        }}
                        className={`w-full pl-9 pr-3.5 py-3 text-sm bg-[#FAF9F5] border rounded-none focus:outline-none focus:border-black font-mono transition-colors ${
                          errors.phone ? 'border-red-500' : 'border-[#D9D3C5]'
                        }`}
                      />
                    </div>
                    {errors.phone && (
                      <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> {errors.phone}
                      </p>
                    )}
                  </div>

                  {/* WhatsApp Toggle & Optional Revealed Input */}
                  <div className="p-3 bg-[#FAF9F5] border border-[#E7E4DC]">
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <div className="relative inline-flex items-center">
                        <input
                          type="checkbox"
                          checked={hasSeparateWhatsapp}
                          onChange={(e) => {
                            setHasSeparateWhatsapp(e.target.checked);
                            if (!e.target.checked) {
                              setWhatsapp('');
                              if (errors.whatsapp) setErrors({ ...errors, whatsapp: '' });
                            }
                          }}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-[#D9D3C5] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#25D366]"></div>
                      </div>
                      <span className="text-xs text-[#2D2A26] font-medium">
                        My WhatsApp number is different from my phone number
                      </span>
                    </label>

                    {hasSeparateWhatsapp && (
                      <div className="mt-3 pt-3 border-t border-[#E7E4DC]">
                        <label className="block text-xs font-semibold uppercase tracking-wider text-[#141414] mb-1 flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <MessageSquare className="w-3.5 h-3.5 text-[#25D366]" />
                            WhatsApp Number <span className="text-red-500">*</span>
                          </span>
                          <span className="text-[10px] text-[#25D366] font-medium">
                            Optional alternate number
                          </span>
                        </label>
                        <input
                          type="tel"
                          placeholder="0801 234 5678 (WhatsApp)"
                          value={whatsapp}
                          onChange={(e) => {
                            setWhatsapp(e.target.value);
                            if (errors.whatsapp) setErrors({ ...errors, whatsapp: '' });
                          }}
                          className={`w-full px-3.5 py-3 text-sm bg-white border rounded-none focus:outline-none focus:border-black font-mono transition-colors ${
                            errors.whatsapp ? 'border-red-500' : 'border-[#D9D3C5]'
                          }`}
                        />
                        {errors.whatsapp && (
                          <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" /> {errors.whatsapp}
                          </p>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Street Address & House / Flat No. (as it currently is) */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#141414] mb-1">
                      Street Address and House / Flat No. <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Flat 4B, Plot 12 Admiralty Way, Lekki Phase 1"
                      value={streetAddress}
                      onChange={(e) => {
                        setStreetAddress(e.target.value);
                        if (errors.streetAddress) setErrors({ ...errors, streetAddress: '' });
                      }}
                      className={`w-full px-3.5 py-3 text-sm bg-[#FAF9F5] border rounded-none focus:outline-none focus:border-black transition-colors ${
                        errors.streetAddress ? 'border-red-500' : 'border-[#D9D3C5]'
                      }`}
                    />
                    {errors.streetAddress && (
                      <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> {errors.streetAddress}
                      </p>
                    )}
                  </div>

                  {/* State & Closest Landmark / Bus Stop */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#141414] mb-1">
                        State <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        className="w-full px-3.5 py-3 text-sm bg-[#FAF9F5] border border-[#D9D3C5] rounded-none focus:outline-none focus:border-black cursor-pointer"
                      >
                        {NIGERIAN_STATES.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#141414] mb-1">
                        Closest Bustop / Landmark
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Near Ebeano Supermarket"
                        value={landmark}
                        onChange={(e) => setLandmark(e.target.value)}
                        className="w-full px-3.5 py-3 text-sm bg-[#FAF9F5] border border-[#D9D3C5] rounded-none focus:outline-none focus:border-black"
                      />
                    </div>
                  </div>

                  {/* Continue Button (Full width in all modes) */}
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={handleProceedToStep3}
                      className="w-full py-4 px-6 bg-[#842A46] hover:bg-[#6f2239] active:scale-[0.99] text-white text-xs font-bold uppercase tracking-widest transition-all cursor-pointer shadow-sm text-center flex items-center justify-center gap-2"
                    >
                      <span>Continue to Shipping Speed</span>
                      <span>→</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-[#545048] space-y-1">
                  <div className="font-bold text-[#141414]">{fullName || 'Customer'}</div>
                  <div>{streetAddress || 'Address specified'}, {state}{landmark ? ` (${landmark})` : ''}</div>
                  <div className="font-mono text-[#735D43]">
                    {phone} {hasSeparateWhatsapp && whatsapp ? `• WA: ${whatsapp}` : ''}
                  </div>
                </div>
              )}
            </div>

            {/* ================= STEP 3: DELIVERY SPEED ================= */}
            <div
              ref={step3Ref}
              className={`bg-white border transition-all ${
                currentStep === 3
                  ? 'border-black shadow-sm p-5 sm:p-6'
                  : 'border-[#E0DBD0] p-4 opacity-90'
              }`}
            >
              <div className="flex items-center justify-between border-b border-[#E7E4DC] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-black text-white text-xs font-mono font-bold flex items-center justify-center">
                    3
                  </span>
                  <h2 className="font-editorial text-lg font-bold uppercase tracking-wide">
                    Delivery Speed
                  </h2>
                </div>
                {currentStep > 3 && (
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentStep(3);
                      scrollToStep(3);
                    }}
                    className="text-xs font-semibold text-[#842A46] uppercase hover:underline cursor-pointer"
                  >
                    Edit
                  </button>
                )}
              </div>

              {currentStep === 3 ? (
                <div className="space-y-4">
                  {/* Option 1: Standard Free */}
                  <label
                    onClick={() => setDeliveryMethod('standard_free')}
                    className={`block p-4 border cursor-pointer transition-all ${
                      deliveryMethod === 'standard_free'
                        ? 'border-black bg-[#FAF9F5] ring-1 ring-black'
                        : 'border-[#D9D3C5] hover:border-black'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center ${
                            deliveryMethod === 'standard_free'
                              ? 'border-black bg-black text-white'
                              : 'border-gray-400'
                          }`}
                        >
                          {deliveryMethod === 'standard_free' && (
                            <span className="w-1.5 h-1.5 rounded-full bg-white" />
                          )}
                        </div>
                        <div>
                          <div className="text-xs sm:text-sm font-bold text-[#141414] uppercase tracking-wider">
                            Standard Doorstep Express (24–48 Hours)
                          </div>
                          <div className="text-xs text-[#5C574F] mt-0.5">
                            Delivered safely to your door or office by our trained courier team.
                          </div>
                        </div>
                      </div>
                      <span className="text-xs font-bold uppercase tracking-wider text-[#52B788]">
                        FREE
                      </span>
                    </div>
                  </label>

                  {/* Option 2: VIP Express */}
                  <label
                    onClick={() => setDeliveryMethod('vip_express')}
                    className={`block p-4 border cursor-pointer transition-all ${
                      deliveryMethod === 'vip_express'
                        ? 'border-black bg-[#FAF9F5] ring-1 ring-black'
                        : 'border-[#D9D3C5] hover:border-black'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center ${
                            deliveryMethod === 'vip_express'
                              ? 'border-black bg-black text-white'
                              : 'border-gray-400'
                          }`}
                        >
                          {deliveryMethod === 'vip_express' && (
                            <span className="w-1.5 h-1.5 rounded-full bg-white" />
                          )}
                        </div>
                        <div>
                          <div className="text-xs sm:text-sm font-bold text-[#141414] uppercase tracking-wider flex items-center gap-2">
                            <span>VIP Priority Morning Delivery</span>
                            <span className="bg-[#E5A83B] text-black text-[9px] font-bold px-1 py-0.5">
                              FAST-TRACK
                            </span>
                          </div>
                          <div className="text-xs text-[#5C574F] mt-0.5">
                            Priority dispatch queue. Guaranteed delivery window before 12 Noon.
                          </div>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-[#141414] font-mono tabular-nums">
                        +₦3,000
                      </span>
                    </div>
                  </label>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={handleProceedToStep4}
                      className="w-full sm:w-auto px-8 py-3.5 bg-[#842A46] hover:bg-[#6f2239] active:scale-[0.99] text-white text-xs font-bold uppercase tracking-widest transition-all cursor-pointer shadow-sm"
                    >
                      Continue to Payment Method →
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-[#545048] flex items-center justify-between">
                  <span>
                    {deliveryMethod === 'standard_free'
                      ? 'Standard Doorstep Express (24–48 Hours)'
                      : 'VIP Priority Morning Delivery'}
                  </span>
                  <span className="font-bold text-[#141414]">
                    {deliveryMethod === 'standard_free' ? 'FREE' : '+₦3,000'}
                  </span>
                </div>
              )}
            </div>

            {/* ================= STEP 4: PAYMENT METHOD (PAYMENT ON DELIVERY) ================= */}
            <div
              ref={step4Ref}
              className={`bg-white border transition-all ${
                currentStep === 4
                  ? 'border-black shadow-sm p-5 sm:p-6'
                  : 'border-[#E0DBD0] p-4 opacity-90'
              }`}
            >
              <div className="flex items-center justify-between border-b border-[#E7E4DC] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-black text-white text-xs font-mono font-bold flex items-center justify-center">
                    4
                  </span>
                  <h2 className="font-editorial text-lg font-bold uppercase tracking-wide">
                    Payment Method
                  </h2>
                </div>
              </div>

              {currentStep === 4 ? (
                <div className="space-y-4">
                  {/* Option 1: POD (Pre-selected) */}
                  <label
                    onClick={() => setPaymentMethod('cod')}
                    className={`block p-4 border cursor-pointer transition-all ${
                      paymentMethod === 'cod'
                        ? 'border-[#52B788] bg-[#F3F9F5] ring-2 ring-[#52B788]'
                        : 'border-[#D9D3C5] hover:border-black'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-5 h-5 rounded-full border mt-0.5 flex items-center justify-center ${
                          paymentMethod === 'cod'
                            ? 'border-[#52B788] bg-[#52B788] text-white'
                            : 'border-gray-400'
                        }`}
                      >
                        {paymentMethod === 'cod' && <Check className="w-3.5 h-3.5" />}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs sm:text-sm font-bold text-[#144729] uppercase tracking-wider">
                            Payment on Delivery (Cash or Bank Transfer to Rider)
                          </span>
                          <span className="bg-[#144729] text-white text-[9px] font-bold px-1.5 py-0.2 uppercase">
                            Recommended
                          </span>
                        </div>
                        <p className="text-xs text-[#205234] leading-relaxed">
                          Pay <strong>ZERO kobo now</strong>. You only pay when the rider arrives, after you open the box and confirm your shoe fit and satisfaction.
                        </p>
                      </div>
                    </div>
                  </label>

                  {/* Option 2: Pre-pay / Instant Transfer */}
                  <label
                    onClick={() => setPaymentMethod('instant_transfer')}
                    className={`block p-4 border cursor-pointer transition-all ${
                      paymentMethod === 'instant_transfer'
                        ? 'border-black bg-[#FAF9F5] ring-1 ring-black'
                        : 'border-[#D9D3C5] hover:border-black'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center ${
                          paymentMethod === 'instant_transfer'
                            ? 'border-black bg-black text-white'
                            : 'border-gray-400'
                        }`}
                      >
                        {paymentMethod === 'instant_transfer' && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </div>
                      <div>
                        <div className="text-xs sm:text-sm font-bold text-[#141414] uppercase tracking-wider">
                          Direct Instant Bank Transfer
                        </div>
                        <div className="text-xs text-[#5C574F] mt-0.5">
                          Receive official company bank account details on the next screen to make transfer.
                        </div>
                      </div>
                    </div>
                  </label>

                  {/* Optional Order Bump Checkboxes */}
                  <div className="pt-4 border-t border-[#E7E4DC] space-y-3">
                    <span className="block text-xs font-bold uppercase tracking-wider text-[#141414]">
                      Recommended Add-ons (Special Checkout Bundle Pricing):
                    </span>

                    {ADDONS.map((addon) => {
                      const isChecked = selectedAddonIds.includes(addon.id);
                      return (
                        <div
                          key={addon.id}
                          onClick={() => toggleAddon(addon.id)}
                          className={`p-3 border flex items-center justify-between cursor-pointer transition-all ${
                            isChecked
                              ? 'border-[#842A46] bg-[#FCF8F9]'
                              : 'border-[#DDD6C8] bg-white hover:border-[#141414]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-4 h-4 border flex items-center justify-center ${
                                isChecked
                                  ? 'bg-[#842A46] border-[#842A46] text-white'
                                  : 'border-[#8C877E]'
                              }`}
                            >
                              {isChecked && <Check className="w-3 h-3" />}
                            </div>
                            <div className="text-xs">
                              <div className="font-bold text-[#141414]">{addon.name}</div>
                              <div className="text-[11px] text-[#736E65]">{addon.description}</div>
                            </div>
                          </div>
                          <div className="text-right shrink-0 ml-2">
                            <div className="text-xs font-bold text-[#141414] font-mono tabular-nums">
                              +₦{addon.price.toLocaleString()}
                            </div>
                            <div className="text-[10px] text-[#8C877E] line-through font-mono">
                              ₦{addon.originalPrice.toLocaleString()}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Final Submit CTA */}
                  <div className="pt-4 space-y-3">
                    <button
                      type="button"
                      disabled={isSubmitting}
                      onClick={handleFinalSubmit}
                      className="w-full bg-[#842A46] hover:bg-[#6f2239] active:scale-[0.99] text-white py-4 px-6 text-sm sm:text-base font-bold uppercase tracking-widest transition-all shadow-lg flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span className="flex items-center gap-2">
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>Generating Order & Dispatch Ticket...</span>
                        </span>
                      ) : (
                        <span>
                          PLACE ORDER — PAY ₦{grandTotal.toLocaleString()} ON DELIVERY
                        </span>
                      )}
                    </button>

                    <p className="text-[11px] text-center text-[#736E65] leading-relaxed">
                      By clicking "Place Order", you agree to receive a phone call from our dispatch supervisor within 2 hours to confirm your address before your rider departs.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-[#545048]">
                  <span>Payment on Delivery (Cash or Bank Transfer upon arrival)</span>
                </div>
              )}
            </div>
          </div>

          {/* ================= RIGHT 5 COLS: ADIDAS STICKY ORDER SUMMARY ================= */}
          <div
            className={`lg:col-span-5 space-y-4 ${
              showMobileSummary ? 'block' : 'hidden lg:block'
            }`}
          >
            <div className="bg-white border border-[#141414] p-5 sm:p-6 sticky top-24 shadow-sm space-y-5">
              <h3 className="font-editorial text-lg font-bold uppercase tracking-wide border-b border-[#E7E4DC] pb-3">
                Order Summary
              </h3>

              {/* Product preview card */}
              <div className="flex gap-4 items-start">
                <div className="w-20 h-20 bg-[#F3EFE7] border border-[#DDD5C5] shrink-0 overflow-hidden relative">
                  <img
                    src={selectedColorway.image}
                    alt={selectedColorway.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-[#735D43]">
                    {SNEAKER_PRODUCT.brand}
                  </div>
                  <h4 className="font-editorial text-sm font-bold text-[#141414] truncate">
                    {SNEAKER_PRODUCT.title}
                  </h4>
                  <div className="text-xs text-[#545048]">
                    Color: <strong className="text-[#141414]">{selectedColorway.name}</strong>
                  </div>
                  <div className="flex items-center justify-between pt-0.5">
                    <div className="flex items-center gap-2 text-xs text-[#545048]">
                      <span>Size: <strong className="text-[#141414]">EU {selectedSize}</strong></span>
                      <span>·</span>
                      <span>Qty: <strong className="text-[#141414]">{selectedBundle.pairs} Pair{selectedBundle.pairs > 1 ? 's' : ''}</strong></span>
                    </div>
                    {currentStep !== 1 && (
                      <button
                        type="button"
                        onClick={() => {
                          setCurrentStep(1);
                          scrollToStep(1);
                        }}
                        className="text-[11px] font-semibold text-[#842A46] uppercase hover:underline cursor-pointer shrink-0"
                      >
                        Change
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-2 border-t border-b border-[#E7E4DC] py-4 text-xs">
                <div className="flex justify-between text-[#5C574F]">
                  <span>Original Value:</span>
                  <span className="line-through font-mono">
                    ₦{selectedBundle.originalPrice.toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between text-[#5C574F]">
                  <span>Black Friday Bundle Price:</span>
                  <span className="font-mono text-[#141414] font-semibold">
                    ₦{selectedBundle.totalPrice.toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between text-[#842A46] font-semibold">
                  <span>Savings Applied (77% OFF):</span>
                  <span className="font-mono">-₦{selectedBundle.savingsTotal.toLocaleString()}</span>
                </div>

                <div className="flex justify-between text-[#5C574F]">
                  <span>Doorstep Delivery:</span>
                  <span className="font-mono font-semibold text-[#52B788]">
                    {deliveryFee === 0 ? 'FREE' : `+₦${deliveryFee.toLocaleString()}`}
                  </span>
                </div>

                {selectedAddonIds.length > 0 && (
                  <div className="flex justify-between text-[#5C574F]">
                    <span>Add-ons ({selectedAddonIds.length}):</span>
                    <span className="font-mono font-semibold text-[#141414]">
                      +₦{addonsTotal.toLocaleString()}
                    </span>
                  </div>
                )}
              </div>

              {/* Grand Total */}
              <div className="flex items-baseline justify-between pt-1">
                <div>
                  <div className="text-xs uppercase font-bold tracking-wider text-[#141414]">
                    Total Payable on Delivery:
                  </div>
                  <div className="text-[11px] text-[#52B788] font-medium">
                    (Zero advance payment required)
                  </div>
                </div>
                <div className="font-editorial text-2xl sm:text-3xl font-extrabold text-[#141414] font-mono tabular-nums">
                  ₦{grandTotal.toLocaleString()}
                </div>
              </div>

              {/* Guarantees Box */}
              <div className="p-3 bg-[#FAF9F5] border border-[#E7E4DC] text-[11px] space-y-1.5 text-[#545048]">
                <div className="font-semibold text-[#141414] uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#52B788]" /> What happens next:
                </div>
                <ul className="space-y-1 list-disc list-inside text-[#666]">
                  <li>Our dispatch manager calls to confirm your address.</li>
                  <li>Rider delivers within 24-48 hours.</li>
                  <li>You inspect and try on the shoe before paying.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

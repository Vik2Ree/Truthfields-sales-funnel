import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#F5F2EB] text-[#5C574F] border-t border-[#E7E4DC] pt-10 pb-24 md:pb-12 text-xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          {/* Brand Lockup */}
          <div className="space-y-1">
            <span className="font-crest text-xs tracking-[0.3em] uppercase text-[#735D43] font-semibold block">
              TRUTHFIELD
            </span>
            <span className="font-editorial text-lg sm:text-xl font-bold text-[#141414] tracking-widest uppercase block">
              INT'L LTD
            </span>
            <p className="text-[11px] text-[#8C877E]">
              Authentic Footwear & Premium Apparel Distribution
            </p>
          </div>

          {/* Contact & Support */}
          <div className="text-[11px] text-[#736E65] space-y-1.5 md:text-right">
            <div className="flex flex-wrap md:justify-end items-center gap-1.5">
              <span>Support Call & WhatsApp:</span>
              <a
                href="https://wa.me/+2348102268521"
                target="_blank"
                rel="noopener noreferrer"
                className="font-bold text-[#842A46] hover:text-[#5e1d31] underline decoration-[#842A46]/40 underline-offset-2 transition-colors"
              >
                08102268521
              </a>
            </div>
            <div>Support Hours: Monday – Saturday (8:00 AM – 9:00 PM)</div>
            <div className="text-[#8C877E] pt-1">
              © {new Date().getFullYear()} Truthfield Int'l Ltd. All rights reserved.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

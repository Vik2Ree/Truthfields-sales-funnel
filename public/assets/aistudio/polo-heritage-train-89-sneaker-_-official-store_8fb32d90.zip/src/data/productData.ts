import { BundleOption, Colorway, Review, AddonItem } from '../types';

export const PROMO_CAMPAIGN_BANNER = '/assets/aistudio/file_0000000088c081f492f161e2dfc5c5ea_b504da20.png';
export const FEATURE_LIFESTYLE_BANNER = '/assets/aistudio/Fitted_Comfort_Sneaker_Feature_Banner_fa0f9bbf.png';
export const TERRAIN_FEATURE_BANNER = '/assets/aistudio/file_00000000d25081f484f0acb9ccd9cdcd_60c5b58d.jpg';

export const SNEAKER_PRODUCT = {
  brand: 'U.S. POLO ASSN.',
  collection: 'HERITAGE SPORT EST. 1890',
  title: 'Train 89 Suede & Oxford Sneaker',
  modelCode: 'POLO-TR89-V2',
  originalPrice: 258000,
  salePrice: 60000,
  discountPercentage: 77,
  rating: 4.9,
  reviewCount: 348,
  inStockCount: 14,
  description:
    'Crafted with hand-finished suede overlays and breathable woven oxford mesh, the Train 89 balances vintage athletics with modern street luxury. Features a molded EVA midsole for high-rebound cushioning, an ergonomic roomy toe-box, and the signature embroidered polo horse crest emblem.',
  highlights: [
    'Hand-stitched premium split suede & ballistic oxford mesh',
    'High-rebound dual-density EVA foam midsole',
    'Engineered ergonomic toe-box for all-day breathing room',
    'High-traction wave vulcanized rubber outsole for rain & dry grip',
    'Signature embroidered polo insignia',
  ],
};

export const COLORWAYS: Colorway[] = [
  {
    id: 'mulberry-taupe',
    name: 'Mulberry Plum & Suede Taupe',
    code: 'PLUM / STONE GREY / CREAM',
    swatchHex: '#6F2B48',
    image: '/src/assets/images/sneaker_mulberry_taupe_1793883955264.jpg',
    badge: 'Featured Hero',
    description: 'Rich vintage plum leather collar with brushed taupe suede and cream oxford mesh.',
  },
  {
    id: 'stealth-black',
    name: 'Stealth Jet Black & White',
    code: 'BLACK / SILVER / MONOCHROME',
    swatchHex: '#18181B',
    image: '/src/assets/images/sneaker_stealth_black_1793883956235.jpg',
    badge: 'Best Seller',
    description: 'Understated matte black suede with silver metallic crest and crisp white midsole.',
  },
  {
    id: 'heritage-navy',
    name: 'Heritage Royal & Sky Blue',
    code: 'NAVY / SKY BLUE / CORAL RED',
    swatchHex: '#223853',
    image: '/src/assets/images/sneaker_heritage_navy_1793883956265.jpg',
    badge: 'Limited Run',
    description: 'Classic collegiate navy with airy sky blue mesh and signature red racing welt.',
  },
];

export const SIZES = [
  { eu: 40, uk: 6.5, us: 7.5, cm: 25.5 },
  { eu: 41, uk: 7.5, us: 8.5, cm: 26.5 },
  { eu: 42, uk: 8.0, us: 9.0, cm: 27.0 },
  { eu: 43, uk: 9.0, us: 10.0, cm: 28.0 },
  { eu: 44, uk: 9.5, us: 10.5, cm: 28.5 },
  { eu: 45, uk: 10.5, us: 11.5, cm: 29.5 },
];

export const BUNDLE_OPTIONS: BundleOption[] = [
  {
    pairs: 1,
    label: '1 Pair (Single Order)',
    pricePerPair: 60000,
    totalPrice: 60000,
    originalPrice: 258000,
    savingsTotal: 198000,
  },
  {
    pairs: 2,
    label: '2 Pairs (Double Pack)',
    pricePerPair: 55000,
    totalPrice: 110000,
    originalPrice: 516000,
    savingsTotal: 406000,
    badge: 'EXTRA ₦10,000 OFF',
    popular: true,
  },
  {
    pairs: 3,
    label: '3 Pairs (Family / Collector Pack)',
    pricePerPair: 51666,
    totalPrice: 155000,
    originalPrice: 774000,
    savingsTotal: 619000,
    badge: 'EXTRA ₦25,000 OFF',
  },
];

export const ADDONS: AddonItem[] = [
  {
    id: 'suede-shield',
    name: 'Nano Suede & Rain Shield Protector Spray (200ml)',
    description: 'Invisible barrier protects your suede from rain, red dirt, stains and spills.',
    originalPrice: 12000,
    price: 5000,
    imageIcon: 'shield',
  },
  {
    id: 'cotton-socks',
    name: 'Polo Performance Cotton Crew Socks (3-Pack)',
    description: 'Cushioned sole & breathable mesh arch band. Black, White & Heather Grey.',
    originalPrice: 9000,
    price: 4000,
    imageIcon: 'socks',
  },
];

export const NIGERIAN_STATES = [
  'Lagos',
  'Abuja (FCT)',
  'Rivers (Port Harcourt)',
  'Oyo (Ibadan)',
  'Ogun',
  'Enugu',
  'Delta',
  'Edo (Benin)',
  'Anambra',
  'Akwa Ibom',
  'Kaduna',
  'Kano',
  'Kwara',
  'Ondo',
  'Cross River',
  'Imo',
  'Abia',
  'Plateau',
  'Other States',
];

export const REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Chinedu O.',
    location: 'Lekki Phase 1, Lagos',
    rating: 5,
    date: '2 days ago',
    title: 'The payment on delivery gave me complete peace of mind',
    comment:
      'I was hesitant at first because of many online scams in Nigeria, but the rider brought it to my office in Lekki. I was allowed to check the shoe and confirm that it was 100% what I ordered before making the bank transfer. Top notch quality!',
    verifiedPurchase: true,
    colorway: 'Mulberry Plum & Suede Taupe',
    size: 43,
  },
  {
    id: 'rev-4',
    author: 'Dr. Fatima K.',
    location: 'Ikeja GRA, Lagos',
    rating: 5,
    date: '1 week ago',
    title: 'Dispatched and delivered within hours',
    comment:
      'I placed my order at 10 AM, a representative from Truthfield called at 11:30 AM to confirm the address that I inputted plus other things he informed me professionally, later the rider was at my gate by 3 PM. I recieved the package and paid with my link. very nice honestly!',
    verifiedPurchase: true,
    colorway: 'Mulberry Plum & Suede Taupe',
    size: 41,
  },
];

export const FAQS = [
  {
    question: 'How does Payment on Delivery (POD) work?',
    answer:
      'It is 100% zero risk for you. You do NOT pay a single kobo upfront online. When the dispatch courier arrives at your doorstep or office, inspect the sneakers, and only pay after you have fully confirmed via the payment link sent to you by your personalized logistics supervisor.',
  },
  {
    question: 'How long does nationwide delivery take?',
    answer:
      'Lagos orders are delivered within 48 hours (often before 36 hours if ordered before 12 PM). Other major cities (Port Harcourt, Ibadan, Benin, Enugu, etc.) would arrive in 3 to 5 working days. Rural locations take 5 to 7 business days. Express delivery is only available in Lagos and can be facilited within 24 hours per request.',
  },
  {
    question: 'Are these sneakers authentic?',
    answer:
      'Yes, 100% authentic U.S. Polo Assn. footwear with original branded packaging, and signature embroidery. You have full right of inspection before paying.',
  },
  {
    question: 'Can I pay via Mobile Bank Transfer to the rider?',
    answer:
      'Payments are only accepted via the secure link sent to you through your personalized logistics supervisor. S/he provides the link once the ride begins and you are asked to pay only when you verify the item.',
  },
];

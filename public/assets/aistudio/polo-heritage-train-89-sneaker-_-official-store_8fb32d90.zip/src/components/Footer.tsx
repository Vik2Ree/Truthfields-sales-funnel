import React from 'react';
import { ShieldCheck, Truck, RotateCcw, Award } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#141414] text-[#FAF9F5] border-t border-white/10 pt-12 pb-24 md:pb-12 text-xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-10">
        {/* 4 Pillars */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pb-8 border-b border-white/10">
          <div className="space-y-1.5">
            <ShieldCheck className="w-5 h-5 text-[#52B788]" />
            <div className="font-bold uppercase tracking-wider text-white">Payment on Delivery</div>
            <p className="text-[#A8A49C] text-[11px] leading-relaxed">
              Open and test the fit before paying cash or mobile transfer.
            </p>
          </div>

          <div className="space-y-1.5">
            <Truck className="w-5 h-5 text-[#E5A83B]" />
            <div className="font-bold uppercase tracking-wider text-white">Nationwide Shipping</div>
            <p className="text-[#A8A49C] text-[11px] leading-relaxed">
              Free 24–48h doorstep delivery across all 36 Nigerian states.
            </p>
          </div>

          <div className="space-y-1.5">
            <RotateCcw className="w-5 h-5 text-[#E5A83B]" />
            <div className="font-bold uppercase tracking-wider text-white">Doorstep Size Swap</div>
            <p className="text-[#A8A49C] text-[11px] leading-relaxed">
              If your size doesn't fit, our dispatch rider swaps it free.
            </p>
          </div>

          <div className="space-y-1.5">
            <Award className="w-5 h-5 text-[#52B788]" />
            <div className="font-bold uppercase tracking-wider text-white">100% Authentic Suede</div>
            <p className="text-[#A8A49C] text-[11px] leading-relaxed">
              Genuine split suede and oxford mesh craftsmanship.
            </p>
          </div>
        </div>

        {/* Brand Lockup & Dispatch Hubs */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 text-[#A8A49C]">
          <div className="space-y-1">
            <span className="font-crest text-xs tracking-[0.3em] uppercase text-[#E5A83B] font-semibold block">
              U.S. POLO ASSN.
            </span>
            <span className="font-editorial text-lg font-bold text-white tracking-widest uppercase block">
              TRAIN 89 HERITAGE RUNNER
            </span>
            <p className="text-[11px] text-[#736E65]">
              Regional Distribution Hubs: Lagos (Ikeja & Lekki) · Abuja (Central Business District) · Port Harcourt (GRA)
            </p>
          </div>

          <div className="text-[11px] text-[#736E65] space-y-1 md:text-right">
            <div>Customer Dispatch Hotline: 0800-POLO-DISPATCH</div>
            <div>Support Hours: Monday – Saturday (8:00 AM – 7:00 PM)</div>
            <div>© {new Date().getFullYear()} Official Storefront. All rights reserved.</div>
          </div>
        </div>
      </div>
    </footer>
  );
};

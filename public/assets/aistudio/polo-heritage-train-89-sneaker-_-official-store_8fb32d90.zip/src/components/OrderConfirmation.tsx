import React from 'react';
import {
  CheckCircle2,
  Package,
  PhoneCall,
  Truck,
  MessageCircle,
  Printer,
  ShieldCheck,
  MapPin,
  Calendar,
  ArrowRight,
  Clock,
} from 'lucide-react';
import { OrderData } from '../types';
import { SNEAKER_PRODUCT } from '../data/productData';

interface OrderConfirmationProps {
  order: OrderData;
  onResetToHome: () => void;
}

export const OrderConfirmation: React.FC<OrderConfirmationProps> = ({
  order,
  onResetToHome,
}) => {
  const primaryItem = order.items[0];

  const handlePrint = () => {
    window.print();
  };

  const whatsappMessage = encodeURIComponent(
    `Hello U.S. Polo Assn Dispatch Team, I just completed my order on your store!\n\nOrder ID: ${order.orderId}\nCustomer: ${order.customer.fullName}\nPhone: ${order.customer.phone}\nColor: ${primaryItem.colorway.name}\nSize: EU ${primaryItem.size}\nTotal Due: ₦${order.grandTotal.toLocaleString()}\nAddress: ${order.customer.streetAddress}, ${order.customer.city}, ${order.customer.state}\n\nPlease confirm my dispatch schedule.`
  );

  return (
    <div className="min-h-screen bg-[#F5F5F3] text-[#141414] py-8 sm:py-12 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Adidas-style Hero Confirmation Banner */}
        <div className="bg-white border-2 border-[#141414] p-6 sm:p-10 shadow-lg text-center space-y-5 relative overflow-hidden">
          <div className="w-16 h-16 rounded-full bg-[#E7F6ED] text-[#2D6A4F] mx-auto flex items-center justify-center border-2 border-[#52B788] shadow-sm">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="font-crest text-xs tracking-[0.3em] uppercase text-[#735D43] font-semibold">
              U.S. POLO ASSN. · OFFICIAL CONFIRMATION
            </span>
            <h1 className="font-editorial text-2xl sm:text-4xl font-extrabold tracking-tight text-[#141414]">
              THANK YOU FOR YOUR ORDER!
            </h1>
            <p className="text-xs sm:text-sm text-[#545048] max-w-lg mx-auto">
              Your order has been logged into our central Lagos & nationwide logistics queue. Your order reference code is:
            </p>
            <div className="inline-block bg-[#F5F2EB] border border-[#DDD6C8] px-4 py-2 font-mono text-base sm:text-lg font-bold text-[#141414] tracking-wider select-all">
              {order.orderId}
            </div>
          </div>

          {/* Urgent Phone Call Notice */}
          <div className="p-4 bg-[#FFFBEB] border border-[#F59E0B] text-left text-xs sm:text-sm text-[#92400E] flex items-start gap-3">
            <PhoneCall className="w-5 h-5 text-[#D97706] shrink-0 mt-0.5 animate-bounce" />
            <div className="space-y-1">
              <strong className="font-bold uppercase tracking-wider block">
                IMPORTANT NEXT STEP: PLEASE KEEP YOUR PHONE NEARBY
              </strong>
              <span>
                Our logistics supervisor will call you on{' '}
                <strong className="underline font-mono">{order.customer.phone}</strong> within 1–2 hours to verify your delivery landmark and dispatch schedule.
              </span>
            </div>
          </div>

          {/* Quick WhatsApp Confirmation Button */}
          <div className="pt-2">
            <a
              href={`https://wa.me/2348000000000?text=${whatsappMessage}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2.5 bg-[#25D366] hover:bg-[#20ba59] text-white px-6 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider shadow-md transition-all cursor-pointer w-full sm:w-auto"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Chat with Dispatch on WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Visual Delivery Status Pipeline */}
        <div className="bg-white border border-[#E0DBD0] p-6 space-y-4 shadow-sm">
          <h2 className="font-editorial text-base sm:text-lg font-bold uppercase tracking-wider text-[#141414] border-b border-[#E7E4DC] pb-3">
            Live Order Status
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 bg-[#E7F6ED] border border-[#52B788] space-y-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#52B788] inline-block" />
              <div className="text-xs font-bold text-[#144729]">1. Order Placed</div>
              <div className="text-[10px] text-[#52B788]">Just Now (Confirmed)</div>
            </div>

            <div className="p-3 bg-[#FFF8E7] border border-[#E5A83B] space-y-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#E5A83B] inline-block animate-pulse" />
              <div className="text-xs font-bold text-[#92400E]">2. Dispatch Call</div>
              <div className="text-[10px] text-[#B45309]">Next 1–2 Hours</div>
            </div>

            <div className="p-3 bg-[#F8F7F3] border border-[#DDD6C8] space-y-1 opacity-70">
              <span className="w-2.5 h-2.5 rounded-full bg-gray-400 inline-block" />
              <div className="text-xs font-bold text-[#141414]">3. In Transit</div>
              <div className="text-[10px] text-[#736E65]">{order.estimatedDeliveryDate}</div>
            </div>

            <div className="p-3 bg-[#F8F7F3] border border-[#DDD6C8] space-y-1 opacity-70">
              <span className="w-2.5 h-2.5 rounded-full bg-gray-400 inline-block" />
              <div className="text-xs font-bold text-[#141414]">4. Inspect & Pay</div>
              <div className="text-[10px] text-[#736E65]">Doorstep Inspection</div>
            </div>
          </div>
        </div>

        {/* Order Details & Receipt Breakdown */}
        <div className="bg-white border border-[#141414] p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex items-center justify-between border-b border-[#E7E4DC] pb-4">
            <div>
              <h3 className="font-editorial text-xl font-bold text-[#141414]">
                Order Receipt & Details
              </h3>
              <p className="text-xs text-[#736E65]">
                Created on {new Date(order.createdAt).toLocaleString()}
              </p>
            </div>
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#141414] hover:text-[#842A46] border border-[#DDD6C8] px-3 py-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print</span>
            </button>
          </div>

          {/* Product Line Item */}
          <div className="flex items-start gap-4 p-4 bg-[#F8F6F0] border border-[#E7E4DC]">
            <div className="w-20 h-20 bg-white border border-[#DDD5C5] shrink-0 overflow-hidden">
              <img
                src={primaryItem.colorway.image}
                alt={primaryItem.colorway.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="min-w-0 flex-1 space-y-1 text-xs">
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#735D43]">
                {SNEAKER_PRODUCT.brand}
              </div>
              <h4 className="font-editorial text-base font-bold text-[#141414]">
                {SNEAKER_PRODUCT.title}
              </h4>
              <div className="text-[#545048]">
                Color: <strong>{primaryItem.colorway.name}</strong>
              </div>
              <div className="flex items-center gap-4 text-[#545048]">
                <span>Size: <strong>EU {primaryItem.size}</strong></span>
                <span>·</span>
                <span>Quantity: <strong>{primaryItem.quantity} Pair(s)</strong></span>
              </div>
            </div>
            <div className="font-editorial text-lg font-bold text-[#141414] font-mono tabular-nums">
              ₦{order.subtotal.toLocaleString()}
            </div>
          </div>

          {/* Add-ons if any */}
          {order.selectedAddons.length > 0 && (
            <div className="space-y-2 border-t border-[#E7E4DC] pt-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#141414]">
                Included Care Kit & Add-ons:
              </span>
              {order.selectedAddons.map((addon) => (
                <div
                  key={addon.id}
                  className="flex justify-between items-center text-xs py-1 px-3 bg-[#FAF9F5] border border-[#E7E4DC]"
                >
                  <span className="font-medium text-[#141414]">{addon.name}</span>
                  <span className="font-mono font-bold">₦{addon.price.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}

          {/* Delivery & Customer Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 border-t border-[#E7E4DC] pt-4 text-xs">
            <div className="space-y-2">
              <span className="font-bold uppercase tracking-wider text-[#141414] flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#842A46]" /> Delivery Destination:
              </span>
              <div className="p-3 bg-[#FAF9F5] border border-[#E7E4DC] space-y-1 leading-relaxed text-[#545048]">
                <div className="font-bold text-[#141414]">{order.customer.fullName}</div>
                <div>{order.customer.streetAddress}</div>
                <div>
                  {order.customer.city}, {order.customer.state}
                </div>
                {order.customer.landmark && (
                  <div className="text-[#735D43]">Landmark: {order.customer.landmark}</div>
                )}
                {order.customer.deliveryNotes && (
                  <div className="italic text-[#8C877E]">Note: "{order.customer.deliveryNotes}"</div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <span className="font-bold uppercase tracking-wider text-[#141414] flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#52B788]" /> Payment & Dispatch Method:
              </span>
              <div className="p-3 bg-[#FAF9F5] border border-[#E7E4DC] space-y-2 text-[#545048]">
                <div>
                  <span className="text-[#8C877E] block text-[10px] uppercase">Payment Terms</span>
                  <span className="font-bold text-[#144729]">
                    Payment on Delivery (Cash or Bank Transfer)
                  </span>
                </div>
                <div>
                  <span className="text-[#8C877E] block text-[10px] uppercase">Estimated Arrival</span>
                  <span className="font-bold text-[#141414] flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#735D43]" /> {order.estimatedDeliveryDate}
                  </span>
                </div>
                <div>
                  <span className="text-[#8C877E] block text-[10px] uppercase">Contact Phone</span>
                  <span className="font-mono font-bold text-[#141414]">{order.customer.phone}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Total Breakdown */}
          <div className="border-t border-[#141414] pt-4 space-y-2 text-xs">
            <div className="flex justify-between text-[#5C574F]">
              <span>Subtotal:</span>
              <span className="font-mono">₦{order.subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-[#5C574F]">
              <span>Delivery Fee:</span>
              <span className="font-mono text-[#52B788] font-bold">
                {order.deliveryFee === 0 ? 'FREE' : `+₦${order.deliveryFee.toLocaleString()}`}
              </span>
            </div>
            <div className="flex justify-between items-baseline pt-2 border-t border-[#E7E4DC]">
              <span className="text-sm font-bold uppercase tracking-wider text-[#141414]">
                Total Amount Due on Delivery:
              </span>
              <span className="font-editorial text-2xl font-extrabold text-[#141414] font-mono tabular-nums">
                ₦{order.grandTotal.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Back to Home CTA */}
        <div className="text-center pt-4">
          <button
            type="button"
            onClick={onResetToHome}
            className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest bg-[#842A46] hover:bg-[#6f2239] active:scale-[0.99] text-white px-6 py-3 transition-all cursor-pointer shadow-sm"
          >
            <span>← Return to Product Storefront</span>
          </button>
        </div>
      </div>
    </div>
  );
};
